from itertools import groupby
from operator import itemgetter
import sys

def read_map_output(file):
    for line in file:
        yield line.rstrip().split(',', 1)

def main():
    # input comes from STDIN (standard input)
    data = read_map_output(sys.stdin)
    # groupby groups multiple word-count pairs by word,
    # and creates an iterator that returns consecutive keys and their group:
    #   current_word - string containing a word (the key)
    #   group - iterator yielding all ["<current_word>", "<count>"] items
    for current_word, group in groupby(sorted(data), itemgetter(0)):
        try:
            total_count = sum(int(count) for current_word, count in group)
            print("%s,%d" % (current_word, total_count))
        except ValueError:
            # count was not a number, so silently discard this item
            pass

if __name__ == "__main__":
    main()