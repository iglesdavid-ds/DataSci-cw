import csv
import eventlet
import eventlet.wsgi
import re
import socketio
import sys
import csv
import eventlet
import eventlet.wsgi
import re
import socketio
from flask import Flask, render_template
from itertools import groupby
from operator import itemgetter

sio = socketio.Server()
app = Flask(__name__)
port = 8000
separator='\t'

@sio.on('connect')
def connect(sid, environ):
    print('connected.', sid)

@sio.on('disconnect')
def disconnect(sid):
    print('disconnect ', sid)

@sio.on('add')
def mult_numbers(sid, a, b):
    data = a * b
    print('Data Processed on Server (add):', data)
    return data

if __name__ == '__main__':
    # wrap Flask application with socketio's middleware
    app = socketio.Middleware(sio, app)

    # deploy as an eventlet WSGI server
    eventlet.wsgi.server(eventlet.listen(('', port)), app)