##Scenario 1 

prop.test(x = 28, n = 94, p=0.16, alternative = "less")
# 
# [6] -- Sunday, February 02, 2020 -- 22:33:52
# t tests - Means: Difference from constant (one sample case)
# Analysis:	A priori: Compute required sample size 
# Input:	Tail(s)	=	One
# Effect size d	=	0.5
# ?? err prob	=	0.05
# Power (1-?? err prob)	=	.8
# Output:	Noncentrality parameter ??	=	2.5980762
# Critical t	=	1.7056179
# Df	=	26
# Total sample size	=	27
# Actual power	=	0.8118316
# 

##Scenario 2 - Ind Chi-Squared

install.packages("gmodels")
library("gmodels")
antiseptics <- read.csv("~/Data Science/1. advStats/Lesson 10 - Final Project/antiseptics.csv")
CrossTable(antiseptics$Clinic, antiseptics$Number.of.applications, fisher=TRUE, chisq = TRUE, expected = TRUE, sresid=TRUE, format="SPSS")

## Scenario 3 - One-Way ANOVA
library("dplyr")
library("rcompanion")
savings <- read.csv("~/Data Science/1. advStats/Lesson 10 - Final Project/savings.csv")
plotNormalHistogram(savings$Group.A)
plotNormalHistogram(savings$Group.B)
plotNormalHistogram(savings$Group.C)
plotNormalHistogram(savings$Group.D)
ANOVA1 <- lm(Group.A ~ Group.B, data=savings)
ANOVA1 <- lm(Group.A ~ Group.C, data=savings)
ANOVA1 <- lm(Group.A ~ Group.D, data=savings)
ANOVA1 <- lm(Group.B ~ Group.B, data=savings)
Anova(ANOVA1, Type="II", white.adjust=TRUE)
# [7] -- Sunday, February 02, 2020 -- 22:36:39
# F tests - ANOVA: Fixed effects, omnibus, one-way
# Analysis:	A priori: Compute required sample size 
# Input:	Effect size f	=	0.25
# ?? err prob	=	0.05
# Power (1-?? err prob)	=	.8
# Number of groups	=	4
# Output:	Noncentrality parameter ??	=	11.2500000
# Critical F	=	2.6559389
# Numerator df	=	3
# Denominator df	=	176
# Total sample size	=	180
# Actual power	=	0.8039869


##Scenario 4 - Two-Proportion z Test
prop.test(x = c(74, 129), n = c(245, 503),
          alternative = "less")
#   [5] -- Sunday, February 02, 2020 -- 22:32:58
# t tests - Means: Difference between two independent means (two groups)
# Analysis:	A priori: Compute required sample size 
# Input:	Tail(s)	=	One
# Effect size d	=	0.5
# ?? err prob	=	0.05
# Power (1-?? err prob)	=	.8
# Allocation ratio N2/N1	=	1
# Output:	Noncentrality parameter ??	=	2.5248762
# Critical t	=	1.6602343
# Df	=	100
# Sample size group 1	=	51
# Sample size group 2	=	51
# Total sample size	=	102
# Actual power	=	0.8058986