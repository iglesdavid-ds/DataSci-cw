import csv
import eventlet
import eventlet.wsgi
import re
import socketio
import sys
from flask import Flask, render_template
from itertools import groupby
from operator import itemgetter

sio = socketio.Server()
app = Flask(__name__)
port = 8000
separator = '\t'


@sio.on('connect')
def connect(sid, environ):
    print('connected.', sid)


@sio.on('disconnect')
def disconnect(sid):
    print('disconnect ', sid)


@sio.on('add')
def read_map_output(file):
    for line in file:
        yield line.rstrip().split(',', 1)


# input comes from STDIN (standard input)
data = read_map_output(sys.stdin)
# groupby groups multiple word-count pairs by word,
# and creates an iterator that returns consecutive keys and their group:
#   current_word - string containing a word (the key)
#   group - iterator yielding all ["<current_word>", "<count>"] items
for current_word, group in groupby(sorted(data), itemgetter(0)):
    try:
        total_count = sum(int(count) for current_word, count in group)
    except ValueError:
        # count was not a number, so silently discard this item
        pass

    print('Data Processed on Server (add):',
          "%s,%d" % (current_word, total_count))
    #return data

if __name__ == '__main__':
    # wrap Flask application with socketio's middleware
    app = socketio.Middleware(sio, app)

    # deploy as an eventlet WSGI server
    eventlet.wsgi.server(eventlet.listen(('', port)), app)
Manager
from socketIO_client import SocketIO, LoggingNamespace
import csv


# Process server response
def on_response(*args):
    print('Data Received by Manager:', args[0])


arrest_list = []
# Send a request to the server to add two numbers
# Open the 'crimes-sample-10k.csv' file
with open('clean-data.csv', 'r') as csvfile:
    crimes_reader = csv.DictReader(csvfile)

    # Filter the row's "Arrest" value
    for row in crimes_reader:
        arrest_list.append(row['Primary Type'])

    # Print the mapped data
    for entry in arrest_list:
        print('%s,%d' % (entry, 1))

# Servers and ports for worker communication
ports = {
    'server_one': {
        'port_number': 8000,
        'status': 'Ready'
    },
}

# Crimes
with SocketIO('localhost', ports['server_one']['port_number'],
              LoggingNamespace) as socketIO:
    socketIO.emit('add', arrest_list, callback=on_response)
    socketIO.wait_for_callbacks(seconds=5)

#with SocketIO('localhost', ports['server_one']['port_number'],
#              LoggingNamespace) as socketIO:
#    socketIO.emit('add' callback=on_response)
#    socketIO.wait_for_callbacks(seconds=5)