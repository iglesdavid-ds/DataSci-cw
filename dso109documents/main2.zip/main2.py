Gizmo = {
    'Type:': 'Cat', 
    'Color:': "black",
    'Nickname:': 'negrita',
    'Owner:' : 'David'
    }

Gadget = {
    'Type:': "Cat",
    'Color:': "white",
    'Nickname:': 'blanquita',
    'Owner:' : 'David'
}
cat_list =[Gizmo, Gadget]

for cat in cat_list:
    for key, value in cat.items():
        print(key, value)
print('\n')

england = {'Capital': 'London'}
france = {'Capital': 'Paris'}
belgium = {'Capital': 'Brussels'}

england['population']='53.01 Million'
england['interesting fact']='Went broke to India from all the tea it purchased in late 1800s'
england['Top Language']='English'
france['population']='66.9 Million'
france['interesting fact']= 'Controlled Spain at one point'
france['Top Language']='French'
belgium['population']='11.35 Million'
belgium['interesting fact']='Leading cause of France being invaded by the Germans'
belgium['Top Language']='English'

country_list = [england, france, belgium]

for country in country_list:
    for key, value in country.items():
        print(key, value)
print('\n')

pizza_order= {
    'Customer Name:':'PJ O\'Rourke',
    'Size:':'Medium',
    'Crust:':'Thin crust',
    'Toppings:':['Olives','Peppers','Ham'],
}
print('Thank you for your order, '+ pizza_order.get('Customer Name:'))
print('You have ordered a ' + pizza_order.get('Size:')+ ',' +pizza_order.get('Crust:')+ ' with the following toppings:')
print(pizza_order.get('Toppings:'))
print('\n')
