from socketio_client import SocketIO, LoggingNamespace
import csv

# Process server response
def on_response(*args):
    print('Data Received by Manager:', args[0])

# Servers and ports for worker communication
ports = {
    'server_one': {
        'port_number': 8000,
        'status': 'Ready'
    },
}
# Send a request to the server 

arrest_list = []

    # Open the 'crimes-sample.csv' file
with open('crimes-sample-10k.csv', 'r') as csvfile:
    crimes_reader = csv.DictReader(csvfile)
	# Filter the row's "Primary Type" value
    for row in crimes_reader:
        #if row['Primary Type'] == 'BATTERY' and row['Arrest'] == 'true':
        arrest_list.append(list((row['Primary Type'], '1')))

with SocketIO('localhost', ports['server_one']['port_number'], LoggingNamespace) as socketIO:
    socketIO.emit('primary_type', arrest_list, callback=on_response)
    socketIO.wait_for_callbacks(seconds=5)
