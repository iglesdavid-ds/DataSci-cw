class Stadium:
    """Makea da Stadium"""
    def __init__(self, name, city_state, capacity):
        """Initializa da Stadium"""
        self.name = name    #: The name of the Cat instance
        self.city_state  = city_state
        self.capacity = capacity
    def describe_stadium(self):
        """Oh, wow no kidding that sounds like a cool Stadium I guess"""
        print("The", self.name, "is located in", self.city_state, "and holds", self.capacity, "fans.")
    def sport_played(self, sport):
        """The sportsball or something iunno who cares"""
        print("The following sport is mainly played in this stadium:", sport)
    def seats_available(self, seats):
        """The sportsball or something iunno who cares"""
        print("There are", seats,"seats still available for tonight's game.")

stadium1=Stadium('Mercedes Benz Arena', 'Atlanta, GA', '70,000')
stadium1.describe_stadium()
stadium1.sport_played('Basketbaseball')
stadium1.seats_available('15000')