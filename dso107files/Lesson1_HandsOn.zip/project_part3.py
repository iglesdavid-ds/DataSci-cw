import sys

search_word = '????'
filename = "project_part3.txt"
count = 0
new_list = []

# Define the method
def filter(list, search_word):
    new_list = []
    for item in list:
        # Ignore "null" items
        if item == search_word:
            continue
        else:
            new_list.append(item)
    return new_list

# Open the file for reading
file_input = []
file = open(filename, "r")
for line in file:
    # Add line to the list
    # "line.strip()" will remove trailing white space
    file_input.append(line.strip())
# Print file input list
print(file_input)

# Print new filtered list
new_list = filter(file_input, search_word)
print(new_list)

# `str` is used to convert the number to a string