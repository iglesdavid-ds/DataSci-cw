library("mvnormtest")
library("car")

kickstarter <- read.csv("~/Data Science/1. advStats/Lesson 8 - MANOVAs/kickstarter.csv")

str(kickstarter$pledged)
str(kickstarter$backers)

kickstarter$pledged <- as.numeric(kickstarter$pledged)
kickstarter$backers <- as.numeric(kickstarter$backers)

keeps <- c("pledged", "backers")
kickstarter1 <- kickstarter[keeps]

kickstarter2 <- kickstarter1[1:5000,]

kickstarter3 <- as.matrix(kickstarter2)

mshapiro.test(t(kickstarter3))

leveneTest(pledged ~ country, data=kickstarter)

leveneTest(backers ~ country, data=kickstarter)

cor.test(kickstarter$pledged, kickstarter$backers, method="pearson", use="complete.obs")
