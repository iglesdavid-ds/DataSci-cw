import unittest

# Part 1

def multiply_numbers(a, b):
    """This Function Multiplies Two Numbers Together And Stores The Result."""
    result = a * b
    return result

class TestMultiplyingNumbers(unittest.TestCase):
    """Tests multiply_numbers() function."""

    def test_numbers(self):
        """Does the multiplication equal a given number?"""
        numbers_multiplied = multiply_numbers(3, 4)
        self.assertEqual(numbers_multiplied, 12)

# Part 2

def new_car(make, model, year):
    """This tests if the year of the car is old or new"""
    if year > 2010:
        return str.format("Nice car! {} {} {}", year, make, model)
    else:
        return str.format("Time for a new car, {} {} {}", year, make, model)

class TestNewCar(unittest.TestCase):
        """Tests new_car()."""

        def test_new_car(self):
            """Will 2017 Nissan Rogue work?"""
            new = new_car('Nissan', 'Rogue', 2017)
            self.assertEqual(new, 'Nice car! 2017 Nissan Rogue')

        def test_year_output(self):
            """Will Nice Car! work?"""
            new_year = new_car('Nissan', 'Rogue', 2009)
            self.assertEqual(new_year, 'Time for a new car, 2009 Nissan Rogue')

unittest.main()