search_word = 'the'
count = 0
new_list = []

# Define the method
def filter(list, search_word):
    new_list = []
    for item in list:
        # Ignore "null" items
        if item == search_word:
            continue
        else:
            new_list.append(item)
    return new_list


word_list = ['the', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']

new_list = filter(word_list, search_word)
print(new_list)
# `str` is used to convert the number to a string