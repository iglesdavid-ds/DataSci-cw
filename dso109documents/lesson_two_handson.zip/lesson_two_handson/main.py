day=6
month="August"
year=1991

my_birthday_is = str(month) + " " + str(day) + ", " + str(year)
print(my_birthday_is)

first = "happy"
second = "birthday"
third = "to"
fourth = "you"

final = first + " " + second  + " " + third  + " " + fourth
print(final.upper())

under_10 = "Not Permitted"
under_15 = "Permitted with a parent"
under_18 = "Permitted with anyone over 18"
over_18 = "Permitted to attend alone"
age = 15
if age < 10:
    print(under_10)
elif age < 15:
    print(under_15)
elif age < 18:
    print(under_18)
else:
    print(over_18)