library("ggplot2")
Y1sq <- nonlinear$Y1^2
Y2sq <- nonlinear$Y2^2

quadModelx1y1 <- lm(nonlinear$X1~nonlinear$Y1+Y1sq)
summary(quadModelx1y1)
quadPlotx1y1 <- ggplot(nonlinear, aes(x = X1, y=Y1)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlotx1y1

quadModelx1y2 <- lm(nonlinear$X1~nonlinear$Y2+Y2sq)
summary(quadModelx1y2)
quadPlotx1y2 <- ggplot(nonlinear, aes(x = X1, y=Y2)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlotx1y2

quadModelx2y1 <- lm(nonlinear$X2~nonlinear$Y1+Y1sq)
summary(quadModelx2y1)
quadPlotx2y1 <- ggplot(nonlinear, aes(x = X2, y=Y1)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlotx2y1

quadModelx2y2 <- lm(nonlinear$X2~nonlinear$Y2+Y2sq)
summary(quadModelx2y2)
quadPlotx2y2 <- ggplot(nonlinear, aes(x = X2, y=Y2)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlotx2y2


exModx1y1 <- lm(log(nonlinear$X1)~nonlinear$Y1)
summary(exModx1y1)

exModx1y2 <- lm(log(nonlinear$X1)~nonlinear$Y2)
summary(exModx1y2)

exModx2y1 <- lm(log(nonlinear$X1)~nonlinear$Y1)
summary(exModx2y1)

exModx2y2 <- lm(log(nonlinear$X1)~nonlinear$Y1)
summary(exModx2y2)

