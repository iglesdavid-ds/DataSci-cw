#Backward Selection
FitAll1 <- lm(IQ ~ ., data = IQ)

summary(FitAll1)

step(FitAll1, direction = 'backward')

#Create another model for only selected varibales and compare their results
fitsome <- lm(IQ ~ Test5 + Test3, data = IQ)
summary(fitsome)

#Backward Selection
FitAll = lm(Y ~ ., data = stepwiseRegression)
summary(FitAll)

step(FitAll, direction = 'backward', scope = formula(FitAll))


#Forward Selection
fitstart = lm(Y ~ 1, data = stepwiseRegression)
summary(fitstart)
step(fitstart, direction = 'forward', scope = formula(FitAll))

#Compare model above with another model with reduced variables, looking for a lower AIC
fitsome <- lm(Y ~ X7 + X11 + X12, data = stepwiseRegression)
summary(fitsome)

#StepWise 
step(fitstart, direction = 'both', scope = formula(FitAll))
