import sys
import csv

def map_input(filter_list):
    for item in filter_list:
        yield(item)

def main():
    arrest_list = []

    # Open the 'crimes-sample.csv' file
    with open('crimes-sample-2.csv', 'r') as csvfile:
        crimes_reader = csv.DictReader(csvfile)

        # Filter the row's "Primary Type" value, counting only battteries that led to arrest
        for row in crimes_reader:
            if row['Primary Type'] == 'BATTERY' and row['Arrest'] == 'true':
                arrest_list.append(row['Primary Type'])

        # Map (Transform) the data
        data = map_input(arrest_list)

        # Print the mapped data
        for entry in data:
            print('%s,%d' % (entry, 1))

if __name__ == "__main__":
    main()