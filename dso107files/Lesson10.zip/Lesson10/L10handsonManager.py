import asyncio
from flask import Flask, render_template
from itertools import groupby
from operator import itemgetter
from socketIO_client import SocketIO, LoggingNamespace

# List of results from workers
callback_results = []
lines8000 = []
lines8001 = []

# Flags to determine if each worker has returned its payload
callback_received_8000 = False
callback_received_8001 = False

# Servers and ports to listen to for worker communication
ports = {
    'server_one': {
        'port_number': 8000,
        'status': 'Ready'
    },
    'server_two': {
        'port_number': 8001,
        'status': 'Ready'
    },
}


# Respond to worker callback
def on_response(*args):
    global callback_results
    global callback_received_8000
    global callback_received_8001

    # Respond to worker 8000
    if args[0]["id"] == "8000":
        callback_received_8000 = True
        callback_results += args[0]["payload"]
    # Respond to worker 8001
    elif args[0]["id"] == "8001":
        callback_received_8001 = True
        callback_results += args[0]["payload"]

    # If both callbacks have returned, reduce the mapped results
    if callback_received_8000 and callback_received_8001 and len(
            callback_results) > 0:
        reduced_results = reduce()
        print("==============RESULTS==============")
        for result in reduced_results:
            print(result)


def read_mapper_output(file, separator=','):
    for line in file:
        yield line.rstrip().split(separator, 1)


def reduce():
    callback_results.sort()
    mapped_results = read_mapper_output(callback_results, separator=',')
    reduced_results = []

    for current_word, group in groupby(mapped_results, itemgetter(0)):
        try:
            total_count = sum(int(count) for current_word, count in group)
            reduced_results.append("%s%s%d" % (current_word, ',', total_count))
        except ValueError:
            # 'count' was not a number, so silently discard this item
            pass

    return reduced_results


def worker1():
    # Worker 1 (8000)
    with SocketIO('localhost', ports['server_one']['port_number'],
                  LoggingNamespace) as socketIO:
        socketIO.emit('worker', lines8000, callback=on_response)
        socketIO.wait_for_callbacks(seconds=5)
        return True


def worker2():
    # Worker 2 (8001)
    with SocketIO('localhost', ports['server_two']['port_number'],
                  LoggingNamespace) as socketIO:
        socketIO.emit('worker', lines8001, callback=on_response)
        socketIO.wait_for_callbacks(seconds=5)
        return True


# Start both workers
def dispatch_workers():
    loop = asyncio.get_event_loop()

    # Run each worker in parallel
    future1 = loop.run_in_executor(None, worker1)
    future2 = loop.run_in_executor(None, worker2)

    # Await results from both workers
    data1 = yield from future1
    data2 = yield from future2


def main():
    global lines8000
    global lines8001

    # Read all lines from the crimes-sample-100k.csv file
    crashes = []
    with open('MVC-10k.csv', 'r') as file:
        for line in file.readlines():
            crashes.append(line)

    # Partition crimes file in half
    halfway_index = int(len(crashes) / 2)
    lines8000 = crashes[0:halfway_index]
    lines8001 = crashes[halfway_index:]

    # Allow both workers to work in parallel
    loop = asyncio.get_event_loop()
    loop.run_until_complete(dispatch_workers())


if __name__ == "__main__":
    main()