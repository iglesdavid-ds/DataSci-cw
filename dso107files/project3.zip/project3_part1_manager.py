from socketio_client import SocketIO, LoggingNamespace

# Process server response
def on_response(*args):
    print('Data Received by Manager:', args[0])

# Servers and ports for worker communication
ports = {
    'server_one': {
        'port_number': 8000,
        'status': 'Ready'
    },
}

# Send a request to the server to add two numbers
num1 = 11
num2 = 36
with SocketIO('localhost', ports['server_one']['port_number'], LoggingNamespace) as socketIO:
    socketIO.emit('add', num1, num2, callback=on_response)
    socketIO.wait_for_callbacks(seconds=5)