search_word = 'the'
count = 0

word_list = ['the', 'universe', 'is', 'all', 'of', 'space', 'and', 'time', 'and', 'its', 'contents', 'which', 'includes', 'planets', 'moons', 'stars', 'galaxies', 'the', 'contents', 'of', 'intergalactic', 'space', 'and', 'all', 'matter', 'and', 'energy']

for item in word_list:
        # Ignore "null" items
        if item == search_word:
            count+=1
# `str` is used to convert the number to a string
print(search_word + ', ' + str(count))