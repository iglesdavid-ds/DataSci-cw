nameQuestion= "What is your name?"
ageQuestions= "How old are you?"
inMonths= "How many months is that?"
nameVar="My name is \"Billy\"."
ageVar=30
monthsVar=360

print(nameQuestion)
print(nameVar)
print(ageQuestions)
print(ageVar)
print(inMonths)
print(monthsVar)

my_string="String"
my_integer=111
my_float=1.11
print(my_string)
print(my_integer)
print(my_float)
