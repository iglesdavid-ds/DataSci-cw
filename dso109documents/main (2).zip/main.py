# Part 1
print("Part 1")
def sum_function(num1, num2, num3):
    return num1 + num2 + num3

print(sum_function(1, 2, 3))

def product_function(number1, number2, number3):
    return number1 * number2 * number3

print(product_function(4, 3, 9))

def average_function(int1, int2, int3):
    return (int1 + int2 + int3)/3

print(average_function(4, 9, 7))

# Part 2
print("Part 2")
sum_function = lambda x, y, z: x+y+z
print(sum_function(1, 2, 3))

product_function = lambda x,y,z: x*y*z
print(product_function(1, 2, 3))

numbers=[1, 2, 3]
average_function = lambda x:sum(x)/len(x)
print(average_function(numbers))
print(sum_function(numbers[0],numbers[1], numbers[2]))

print("Part 3")
list_one = [4, 6, 88, 24]
list_two = [17, 34, 9, 5]
list_three = [63, 20, 98, 4]

average_maker = lambda x, y, z: (x+y+z)/3
map_results = map(average_maker, list_one, list_two, list_three)
print(list(map_results))

