import csv
import eventlet
import eventlet.wsgi
import re
import socketio
from flask import Flask, render_template
from itertools import groupby
from operator import itemgetter

sio = socketio.Server()
app = Flask(__name__)
port = 8001
separator=','

@sio.on('connect')
def connect(sid, environ):
    print('connected.', sid)

@sio.on('disconnect')
def disconnect(sid):
    print('disconnect ', sid)

@sio.on('worker')
def worker(sid, file):
    data = read_input(file)
    separator = ','
    mapped_results = []
    reduced_results = []

    # Mapper
    for datum in data:
        # Add the results to the mapped_results array.
        # The mapper output ('mapped_results') will be the reducer input.
        #
        # comma-delimited; the trivial datum count is 1
        mapped_results.append('%s%s%d' % (datum, separator, 1))

    # Reduce
    data = read_mapper_output(mapped_results)
    reduced_results = []
    for current_word, group in groupby(sorted(data), itemgetter(0)):
        try:
            total_count = sum(int(count) for current_word, count in group)
            reduced_results.append("%s,%d" % (current_word, total_count))
        except ValueError:
            # count was not a number, so silently discard this item
            pass

    results = {}
    results["id"] = str(port)
    results["payload"] = reduced_results
    return results

def read_input(file):
    # Column index: "Arrests" is 9th column.
    column_index = 5

    for l in csv.reader(file, quotechar='"', delimiter=',',quoting=csv.QUOTE_ALL, skipinitialspace=True):
        #if re.match(".*TRUE", l[column_index], re.IGNORECASE):
        yield(l[column_index])
        #elif re.match(".*FALSE", l[column_index], re.IGNORECASE):
            #yield("False")

def read_mapper_output(file, separator=','):
    for line in file:
        yield line.rstrip().split(separator, 1)

if __name__ == '__main__':
    # wrap Flask application with socketio's middleware
    app = socketio.Middleware(sio, app)

    # deploy as an eventlet WSGI server
    eventlet.wsgi.server(eventlet.listen(('', port)), app)
